<?php
    $result = file_get_contents('http://requestb.in/링크부분');
    echo $result;
?>